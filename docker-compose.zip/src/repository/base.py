from datetime import datetime
from typing import Any, Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio.session import AsyncSession
from sqlalchemy.orm import joinedload, selectinload

from src.config import settings
from src.exceptions import NotFoundException


class BaseSQLAlchemyRepository:
    def __init__(self, session: AsyncSession, model_cls) -> None:
        self.session = session
        self.model_cls = model_cls

    def add(self, obj: Any) -> Any:
        self.session.add(obj)
        return obj

    def bulk_add(self, obj_list: list | tuple) -> None:
        self.session.add_all(obj_list)

    async def get(self, field: str, value: Any, joined_load: tuple[str, ...] | None = None) -> Any | None:
        base_q = select(self.model_cls).where(getattr(self.model_cls, field) == value)
        if joined_load:
            base_q = base_q.options(*(joinedload(getattr(self.model_cls, field)) for field in joined_load))
        return (await self.session.execute(base_q)).scalars().first()

    async def delete(self, obj: Any):
        return await self.session.delete(obj)

    async def get_or_error(self, instance_id: int, joined_load: tuple[str, ...] | None = None) -> Any:
        if instance := await self.get('id', instance_id, joined_load=joined_load):
            return instance
        raise NotFoundException(f'{self.model_cls.__name__} with id {instance_id} not found')

    async def get_or_error_by_field(
        self,
        field: str,
        value: Any,
        joined_load: tuple[str, ...] | None = None,
    ) -> Any:
        if instance := await self.get(field, value, joined_load=joined_load):
            return instance
        raise NotFoundException(f'{self.model_cls.__name__} with {field} = {value} not found')

    async def search(
        self,
        filters: dict[str, Any],
        exclude_filters: dict[str, Any] | None = None,
        joined_load: tuple[str, ...] | None = None,
        select_in_load: tuple[str, ...] | None = None,
    ) -> Sequence:
        try:
            filters_q = [getattr(self.model_cls, field) == value for field, value in filters.items()]
        except AttributeError:
            raise ValueError(f'Invalid filter {filters}.')
        q = select(self.model_cls).where(*filters_q)
        if exclude_filters:
            try:
                filters_exc = [getattr(self.model_cls, field) != value for field, value in exclude_filters.items()]
                q = q.where(*filters_exc)
            except AttributeError:
                raise ValueError(f'Invalid exclude_filters {exclude_filters}.')

        if joined_load:
            q = q.options(*(joinedload(getattr(self.model_cls, field)) for field in joined_load))
        if select_in_load:
            q = q.options(*(selectinload(getattr(self.model_cls, field)) for field in select_in_load))
        return (await self.session.execute(q)).scalars().all()

    async def search_or_error(
        self,
        filters: dict[str, Any],
        joined_load: tuple[str, ...] | None = None,
        select_in_load: tuple[str, ...] | None = None,
    ) -> tuple[Any, ...]:
        result = await self.search(filters=filters, joined_load=joined_load, select_in_load=select_in_load)
        if not result:
            raise NotFoundException(f'{self.model_cls.__name__} not found')
        return result  # type: ignore

    async def search_one_or_error(
        self,
        filters: dict[str, Any],
        joined_load: tuple[str, ...] | None = None,
        select_in_load: tuple[str, ...] | None = None,
    ) -> Any:
        result = await self.search_or_error(filters=filters, joined_load=joined_load, select_in_load=select_in_load)
        if len(result) > 1:
            raise ValueError('More than one instance was found!')
        return result[0]  # type: ignore

    def update(self, obj: Any, update_data: dict, changes_as_dict: bool = False) -> list | dict:
        changes_fields = self._update_model(obj, update_data)
        if changes_fields:
            self.session.add(obj)
        return changes_fields if changes_as_dict else list(changes_fields.keys())

    def _update_model(self, obj: Any, update_data: dict) -> dict[str, Any]:
        changes_fields = {}
        for field, new_value in update_data.items():
            if hasattr(obj, field):
                old_value = (
                    getattr(obj, field).strftime(settings.datetime_format)
                    if isinstance(getattr(obj, field), datetime)
                    else getattr(obj, field)
                )
                if old_value != new_value:
                    setattr(obj, field, new_value)
                    changes_fields[field] = new_value
        return changes_fields

    async def get_all(self):
        q = select(self.model_cls)
        return (await self.session.execute(q)).scalars().all()

    async def get_list_by_ids(self, items_ids: list[int]):
        q = select(self.model_cls).where(self.model_cls.id.in_(items_ids))
        return (await self.session.execute(q)).scalars().all()
