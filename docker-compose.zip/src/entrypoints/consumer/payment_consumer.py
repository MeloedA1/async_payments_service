import uuid

from faststream.rabbit import RabbitQueue
from pydantic import BaseModel

from src.entrypoints.dependencies.uow import get_uow
from src.entrypoints.dependencies.rabbit import broker
from src.services.payment_processing import PaymentProcessingService


payments_dlq = RabbitQueue(
    "payments.dlq",
    durable=True,
)

payments_queue = RabbitQueue(
    "payments.new",
    durable=True,
    arguments={
        "x-dead-letter-exchange": "",
        "x-dead-letter-routing-key": "payments.dlq",
    },
)


class PaymentCreatedEvent(BaseModel):
    payment_id: uuid.UUID


@broker.subscriber(payments_queue)
async def handle_payment_created(message: dict) -> None:

    event = PaymentCreatedEvent.model_validate(message)

    service = PaymentProcessingService(
        uow=get_uow(),
    )

    await service.process(event.payment_id)
