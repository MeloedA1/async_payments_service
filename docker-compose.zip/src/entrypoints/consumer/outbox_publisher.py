from datetime import UTC, datetime

from src.entrypoints.dependencies.uow import get_uow
from src.services.uow import Uow
from src.config import logger


async def publish_outbox(
    broker,
    uow: Uow | None = None,
    limit: int | None = None
) -> None:

    uow = uow or get_uow()

    async with uow:
        events = await uow.outbox.get_unpublished(limit)
        ids = [str(x.id) for x in events]
        logger.info('Were found %s unpublished events: %s', len(ids), ids)

        for event in events:
            await broker.publish(
                message=event.payload,
                queue="payments.new",
            )

            event.published = True
            event.published_at = datetime.now(UTC)

        await uow.commit()

    logger.info('Events were published: %s', ids)
